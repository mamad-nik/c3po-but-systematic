# c3po-but-systematic
written in flex &amp; bison

## In order to run ##
after cloning, `cd` into the containing directory and then prompt `make`.

there is going to be a file called `flebi`. you can run and compile your files like this:
```
./flebi <your-file-name>
```
if the copilation proccess was successfull you'l get a 
```
parse complited successfully; there were no errors.
```
otherwise it's gonna be a 
```
error: syntax error
```
